# Seismic Offset check

Check difference between Easting & Northing in **orthogonal** grid.

Preplan loaded to sqlite DB versus daily production SPS


[How to use it](doc/index.md)


### Run from source
* Python 3.8
* pip3 install -r requirements.txt
* python3 main.py

Icons from http://p.yusukekamiyamane.com/