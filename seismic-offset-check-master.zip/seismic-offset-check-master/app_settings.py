"""
    App Settings
"""
ORG = 'mysiar'
APP = 'SeismicOffsetCheck'
LIMIT_X = 'limit_x'
LIMIT_Y = 'limit_y'
DB_PATH = 'db_path'
