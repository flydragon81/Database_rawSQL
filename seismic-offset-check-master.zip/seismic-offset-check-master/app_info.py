"""
    App Information
"""

VERSION = '0.4.0'
TITLE = 'Offset Check'
AUTHOR = 'Piotr Synowiec'
AUTHOR_EMAIL = 'psynowiec@gmail.com'
AUTHOR_WEB = 'https://github.com/mysiar'

APP_DATE = 'September 2020'
HELP_URL = 'https://github.com/mysiar/seismic-offset-check/blob/master/doc/index.md'
LICENSE_URL = 'https://github.com/mysiar/seismic-offset-check/blob/master/LICENSE'
